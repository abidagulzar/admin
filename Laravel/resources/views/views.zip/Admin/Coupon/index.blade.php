@extends('Admin.Layout.master')

@section('pagebreadcrumb')
<ol class="breadcrumb">
	<li>Coupon</li>
	<li>List</li>
</ol>
@endsection
@section('content')
<div class="row">
	<div class="col-xs-12 col-sm-7 col-md-7 col-lg-4">
		@can('Coupon Create')
		<a class="btn btn-success" href="{{ route('admin.coupon.create') }}"> Create New Coupon</a>
		@endcan
		@can('Coupon Delete')
		<a class="btn btn-danger" id="btnDeleteCoupon"> Delete Coupon</a>
		@endcan

	</div>
</div>
<br />
<section id="widget-grid" class="">


	<div class="row">


		<div class="col-md-4">
			<label class="control-label">Store Name</label>
			<select style="width:100%" id="StoreId" name="StoreId" class="select2">


				@if(isset($stores))
				@foreach($stores as $StoreId => $Name)
				{{ $seleced = '' }}

				<option value="{{ $StoreId }}">{{ $Name }}</option>

				@endforeach
				@endif

			</select>
		</div>
	</div>
	<br />
	<!-- row -->
	<div class="row">

		<!-- NEW WIDGET START -->
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

			<!-- Widget ID (each widget will need unique ID)-->
			<div class="jarviswidget jarviswidget-color-darken" id="wid-id-0" data-widget-editbutton="false">
				<!-- widget options:
								usage: <div class="jarviswidget" id="wid-id-0" data-widget-editbutton="false">
				
								data-widget-colorbutton="false"
								data-widget-editbutton="false"
								data-widget-togglebutton="false"
								data-widget-deletebutton="false"
								data-widget-fullscreenbutton="false"
								data-widget-custombutton="false"
								data-widget-collapsed="true"
								data-widget-sortable="false"
				
								-->
				<header>
					<span class="widget-icon"> <i class="fa fa-table"></i> </span>
					<h2>Coupon List</h2>

				</header>

				<!-- widget div-->
				<div>

					<!-- widget edit box -->
					<div class="jarviswidget-editbox">
						<!-- This area used as dropdown edit box -->

					</div>
					<!-- end widget edit box -->

					<!-- widget content -->
					<div class="widget-body no-padding">

						<table id="coupon_table" class="table table-striped table-bordered table-hover" width="100%">
							<thead>
								<tr>
									<th><input type="checkbox" id="selectall" onclick="CouponModule.SelectAllList(this)" /> </th>
									<th>Header</th>
									<th>Code</th>
									<th>Expiry Date</th>
									<th>Is Banner</th>
									<th>Is Home Coupon</th>
									<th>Is Header Coupon</th>
									<th>Is Home Banner</th>
									<th>Is Top Deal</th>
									<th>Store Rank</th>
									<th>Created By</th>
									<th>Create Date/Time</th>
									<th>Update By</th>
									<th>Update Date/Time</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
							<tfoot>
								<tr>
									<th></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th class="searchable"></th>
									<th></th>
								</tr>
							</tfoot>
						</table>

					</div>
					<!-- end widget content -->

				</div>
				<!-- end widget div -->

			</div>
			<!-- end widget -->

		</article>
		<!-- WIDGET END -->

	</div>

	<!-- end row -->

	<!-- end row -->
	@can('Coupon Delete')
	<div id="deleteCouponModal" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Delete Coupon</h4>
				</div>
				<div class="modal-body">
					<div id="deleteCouponText"></div>
				</div>

				<form class="form-horizontal" id="deleteCouponForm" method="post" action="{{ route('admin.coupon.delete') }}">
					{{ csrf_field() }}
					<input type="hidden" id="CouponId" name="CouponId" class="delete" />
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
						<button type="submit" class="btn btn-danger">Yes</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	@endcan

</section>

@endsection
@section('pagescripts')
<script type="text/javascript">
	var CouponModule = (function() {

			var responsiveHelper_coupon_table = undefined;
			var self = {};
			var editCouponModelSelector = "#editCouponModal";
			var editCouponPasswordModelSelector = "#editCouponPasswordModal";
			var createCouponModelSelector = "#createCouponModal";
			var deleteCouponModelSelector = "#deleteCouponModal";

			var couponTable = null;

			var breakpointDefinition = {
				tablet: 1024,
				phone: 480
			};

			self.deleteCouponModal = function(couponId, couponName) {

				$("#deleteCouponText").html("Do you want to delete Coupon with Header <b>" + couponName + "</b> ?");

				$("#CouponId.delete").val(couponId);

				$(deleteCouponModelSelector).modal('show');
			}



			self.BindEvents = function() {

				$('#StoreId').on("select2:select", function(e) {
					couponTable.ajax.reload();
				});

				$("#btnDeleteCoupon").off().click(function() {

					var checked = $(".selectrowcheckbox:checked");
					if (checked.length == 0) {
						showErrorMessgae("Select some coupons to delete.");
					} else {

						$("#deleteCouponText").html("Do you want to delete selected coupons ?");

						var ids = checked.map(function() {
							return $(this).data('id');
						}).get().toString();

						$("#CouponId.delete").val(ids);

						$(deleteCouponModelSelector).modal('show');
					}
				});

			}

			self.SelectAllList = function(obj) {
				if ($(obj).is(":checked")) {
					$(".selectrowcheckbox").attr("checked", "checked").prop("checked", "checked");
				} else {

					$(".selectrowcheckbox").removeAttr("checked")
				}

			}
			//'CouponId', 'Code', 'Header', 'ExpiryDate', 'IsBanner', 'HomeCoupon', 'IsHeaderDeal'
			self.BindCouponTable = function() {
				couponTable = $('#coupon_table').DataTable({
					"deferRender": true,
					"sAjaxSource": "{{ route('admin.coupon.index') }}",
					"fnServerParams": function(aoData) {
						aoData.push({
							"name": "StoreId",
							"value": $("#StoreId").val()

						});
					},
					"aoColumns": [{
							"sWidth": "5%",
							"sClass": "text-center",
							"render": function(data, type, row) {
								return '<input type="checkbox" class="selectrowcheckbox" data-id="' + row.CouponId + '" class=""/>';
							},
						},
						{
							"mData": "Header",
							"sClass": "text-center"
						},
						{
							"mData": "Code",
							"sClass": "text-center"
						},

						{

							"render": function(data, type, row, val) {
								if (row.IsUnknownOutGoing == 1)
									return "Unknown/OutGoing";
								else {
									if (row.ExpiryDate && !row.ExpiryDate.includes("1999")) {
										var splited = row.ExpiryDate.split(' ')[0].split('-');

										return splited[2] + "/" + splited[1] + "/" + splited[0]
									}

									return "";
								}
							},
							"sClass": "text-center"
						},

						{

							"render": function(data, type, row, val) {
								if (row.IsBanner == 1) {
									return "Yes";
								}

								return "No";
							},
							"sClass": "text-center"
						},
						{

							"render": function(data, type, row, val) {
								if (row.HomeCoupon == 1) {
									return "Yes";
								}

								return "No";
							},
							"sClass": "text-center"
						},
						{

							"render": function(data, type, row, val) {
								if (row.IsHeaderDeal == 1) {
									return "Yes";
								}

								return "No";
							},
							"sClass": "text-center"
						},
						{

							"render": function(data, type, row, val) {
								if (row.IsHomeBanner == 1) {
									return "Yes";
								}

								return "No";
							},
							"sClass": "text-center"
						},
						{

							"render": function(data, type, row, val) {
								if (row.IsTopDeal == 1) {
									return "Yes";
								}

								return "No";
							},
							"sClass": "text-center"
						},

						{
							"mData": "StoreRank",
							"sClass": "text-center"
						},
						{
							"mData": "CreatedByUser",
							"sClass": "text-center"
						},
						{

							"render": function(data, type, row, val) {

								if (row.CreateDate) {

									try {
										return (new Date(row.CreateDate)).toLocaleString();
									} catch {
										return "";

									}
								}

								return "";
							},
							"sClass": "text-center"
						},
						{
							"mData": "UpdatedByUser",
							"sClass": "text-center"
						},
						{

							"render": function(data, type, row, val) {

								if (row.UpdateDate) {

									try {
										return (new Date(row.UpdateDate)).toLocaleString();
									} catch {
										return "";

									}
								}

								return "";

							},
							"sClass": "text-center"
						},
						{

							"sWidth": "5%",
							"render": function(data, type, row, val) {

								var actions = '<div class="" style="cursor:pointer">';
								var editAction = "{{ route('admin.coupon.edit', 'id') }}";
								editAction = editAction.replace('id', row.CouponId);
								var dataTitle = row.Header;
								actions += '<a class="green"  href="' + editAction + '"  ><i class="fa fa-pencil datatable-Icon"></i></a>  <a class="red" onClick="CouponModule.deleteCouponModal(' + "\'" + row.CouponId + "\'" + "," + "\'" + dataTitle + "\'" + ')"  ><i class="fa fa-trash-o datatable-Icon"></i></a></div>'

								return actions;
							},
							"sClass": "text-center"
						}
					],
					"sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6 hidden-xs'f><'col-sm-6 col-xs-12 hidden-xs'<'toolbar'>>r>" +
						"t" +
						"<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
					"autoWidth": true,
					"preDrawCallback": function() {
						// Initialize the responsive datatables helper once.
						if (!responsiveHelper_coupon_table) {
							responsiveHelper_coupon_table = new ResponsiveDatatablesHelper($('#coupon_table'), breakpointDefinition);
						}
					},
					"rowCallback": function(nRow) {
						responsiveHelper_coupon_table.createExpandIcon(nRow);
					},
					"drawCallback": function(oSettings) {
						responsiveHelper_coupon_table.respond();
					}

				});



				// Apply the filter
				$("#coupon_table thead th input[type=text]").on('keyup change', function() {

					otable
						.column($(this).parent().index() + ':visible')
						.search(this.value)
						.draw();

				});

				// Setup - add a text input to each footer cell
				$('#coupon_table tfoot th.searchable').each(function() {
					var title = $(this).text();
					$(this).html('<input type="text" placeholder="Search ' + title + '" />');
				});



				// Apply the search
				couponTable.columns().every(function() {
					var that = this;

					$('input', this.footer()).on('keyup change clear', function() {
						if (that.search() !== this.value) {
							that
								.search(this.value)
								.draw();
						}
					});
				});
			}

			return self;
		}()

	);

	jQuery(function($) {
		CouponModule.BindCouponTable();
		CouponModule.BindEvents();
	});
</script>

@endsection