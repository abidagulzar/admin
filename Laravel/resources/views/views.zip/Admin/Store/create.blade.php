@extends('Admin.Layout.master')
@section('pagebreadcrumb')
<ol class="breadcrumb">
    <li>Store</li>
    <li>Create</li>
</ol>
@endsection
@section('content')

<div class="jarviswidget" id="createStoreWidget" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-deletebutton="false" data-widget-sortable="false">

    <header>
        <h2>Create Store </h2>
    </header>

    <!-- widget div-->

    <div>
        <!-- widget edit box -->
        <div class="jarviswidget-editbox">
            <!-- This area used as dropdown edit box -->
            <input class="form-control" type="text">
        </div>
        <!-- end widget edit box -->

        <!-- widget content -->
        <div class="widget-body">
            @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif



            <form id="createStoreForm" action="{{ route('admin.store.createpost') }}" enctype="multipart/form-data" method="POST">
                @csrf
                <fieldset>
                    <legend>Store Basic Info</legend>

                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Store Name</label>
                            <input type="text" class="form-control" name="Name" value="{{ old('Name') }}" placeholder="Store Name" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />
                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Store Site Url</label>

                            <input type="text" class="form-control" name="SiteUrl" value="{{ old('SiteUrl') }}" placeholder="Store Site Url" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />

                        </div>
                    </div>

                </fieldset>
                <fieldset>


                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Store Network Link</label>
                            <input type="text" class="form-control" name="StoreNetworkLink" value="{{ old('StoreNetworkLink') }}" data-bv-group=".col-md-6" placeholder="Store Network Link" data-bv-notempty="true" data-bv-notempty-message="Information Required" />

                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Category</label>
                            <select multiple style="width:100%" id="CategoryId" name="CategoryId[]" class="select2" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required">

                                @if(isset($categories))
                                @foreach($categories as $CategoryId => $Name)
                                {{ $seleced = '' }}

                                <option value="{{ $CategoryId }}" {{ (collect(old('CategoryId'))->contains($CategoryId)) ? 'selected':'' }}>{{ $Name }}</option>

                                @endforeach
                                @endif

                            </select>
                        </div>
                    </div>

                </fieldset>

                <fieldset>

                    <div class="row">
                        <div class="col-md-6">

                            <label class="control-label">Logo(200x200)</label>
                            <div>
                                <input type="file" class="btn btn-default" id="LogoUrl" name="LogoUrl">
                                <p class="help-block">

                                </p>
                            </div>

                        </div>
                        <div class="col-md-6">

                            <label class="control-label">Logo(600X400)</label>
                            <div>
                                <input type="file" class="btn btn-default" id="LogoUrl600X400" name="LogoUrl600X400">
                                <p class="help-block">

                                </p>
                            </div>

                        </div>
                    </div>


                </fieldset>


                <fieldset>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Other Options</label>
                            <div>
                                <label class="checkbox-inline ">
                                    <input id="IsTopStore" {{ old('IsTopStore') == 1 ?  'checked' : '' }} name="IsTopStore" value="1" type="checkbox" class="checkbox style-0" />
                                    <span>Top Store</span>
                                </label>
                                <label class="checkbox-inline">
                                    <input checked="checked" id="Enabled" name="Enabled" {{ old('Enabled') == 1 ?  'checked' : '' }} value="1" type="checkbox" class="checkbox style-0">
                                    <span>Enabled</span>
                                </label>
                                <label class="checkbox-inline">
                                    <input checked="checked" id="IsHomeStore" name="IsHomeStore" {{ old('IsHomeStore') == 1 ?  'checked' : '' }} value="1" type="checkbox" class="checkbox style-0">
                                    <span>Home Store (Show at Home)</span>
                                </label>


                            </div>

                        </div>
                    </div>
                </fieldset>
                <br />
                <legend>Store Content Info</legend>
                <fieldset>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 1</label>

                            <input type="text" class="form-control" name="Header1" value="{{ old('Header1') }}" placeholder="Header 1" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Description 1</label>

                            <textarea rows="4" class="form-control" name="Description1" placeholder="Description 1">{{ old('Description1') }}</textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 2</label>

                            <input type="text" class="form-control" name="Header2" value="{{ old('Header2') }}" placeholder="Header 2" />
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Description 2</label>

                            <textarea rows="4" class="form-control" name="Description2" placeholder="Description 2">{{ old('Description2') }}</textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 3</label>

                            <input type="text" class="form-control" name="Header3" value="{{ old('Header3') }}" placeholder="Header 3" />
                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Description 3</label>

                            <textarea rows="4" class="form-control" name="Description3" placeholder="Description 3">{{ old('Description3') }}</textarea>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 4</label>

                            <input type="text" class="form-control" name="Header4" value="{{ old('Header4') }}" placeholder="Header 4" />
                        </div>
                        <div class="col-md-6">

                            <label class="control-label">Description 4</label>

                            <textarea rows="4" class="form-control" name="Description4" placeholder="Description 4">{{ old('Description4') }}</textarea>

                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 5</label>

                            <input type="text" class="form-control" name="Header5" value="{{ old('Header5') }}" placeholder="Header 5" />
                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Description 5</label>

                            <textarea rows="4" class="form-control" name="Description5" placeholder="Description 5">{{ old('Description5') }}</textarea>

                        </div>
                    </div>
                </fieldset>

                <br />
                <legend>SEO Related Info</legend>
                <fieldset>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Keyword in Url</label>

                            <input type="text" value="coupon-code" class="form-control" id="Keyword" name="Keyword" value="{{ old('Keyword') }}" placeholder="Search Name" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Meta Title</label>

                            <input type="text" class="form-control" name="MetaTitle" value="{{ old('MetaTitle') }}" placeholder="Meta Title" />
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Meta Keyword</label>

                            <input type="text" class="form-control" name="MetaKeyword" value="{{ old('MetaKeyword') }}" placeholder="Meta Keyword" />
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <label class="control-label">Meta Description</label>

                            <textarea rows="4" class="form-control" name="MetaDescription" placeholder="Meta Description">{{ old('MetaDescription') }}</textarea>
                        </div>
                    </div>
                </fieldset>

                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-primary" onsubmit="return validateForm()" type="submit">
                                <i class="fa fa-save"></i>
                                Create Store
                            </button>
                        </div>
                    </div>
                </div>

            </form>
        </div>
        <!-- end widget content -->

    </div>
    <!-- end widget div -->

</div>
<!-- end widget -->

</div>

@endsection
@section('pagescripts')
<script>
    $('#createStoreForm').bootstrapValidator({
        excluded: ':disabled'
    });
</script>

@endsection