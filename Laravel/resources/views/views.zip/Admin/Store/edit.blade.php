@extends('Admin.Layout.master')
@section('pagebreadcrumb')
<ol class="breadcrumb">
    <li>Store</li>
    <li>Edit</li>
</ol>
@endsection
@section('content')

<div class="jarviswidget" id="updateStoreWidget" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-deletebutton="false" data-widget-sortable="false">

    <header>
        <h2>Update Store </h2>
    </header>

    <!-- widget div-->

    <div>
        <!-- widget edit box -->
        <div class="jarviswidget-editbox">
            <!-- This area used as dropdown edit box -->
            <input class="form-control" type="text">
        </div>
        <!-- end widget edit box -->

        <!-- widget content -->
        <div class="widget-body">
            @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif



            <form id="updateStoreForm" action="{{ route('admin.store.updatepost') }}" enctype="multipart/form-data" method="POST">
                @csrf
                <fieldset>
                    <legend>Store Basic Info</legend>

                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Store Name</label>
                            <input type="text" class="form-control" name="Name" value="{{old('Name', $Model->Name)}}" placeholder="Store Name" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />
                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Store Site Url</label>

                            <input type="text" class="form-control" name="SiteUrl" value="{{ old('SiteUrl', $Model->SiteUrl) }}" placeholder="Store Site Url" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />

                        </div>
                    </div>

                </fieldset>
                <fieldset>


                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Store Network Link</label>
                            <input type="text" class="form-control" name="StoreNetworkLink" value="{{ old('StoreNetworkLink', $Model->StoreNetworkLink) }}" data-bv-group=".col-md-6" placeholder="Store Network Link" data-bv-notempty="true" data-bv-notempty-message="Information Required" />

                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Category</label>
                            <select multiple style="width:100%" id="CategoryId" name="CategoryId[]" class="select2" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required">

                                @if(isset($categories))
                                @foreach($categories as $CategoryId => $Name)
                                {{ $seleced = '' }}

                                <option value="{{ $CategoryId }}" {{ (collect(old('CategoryId',$storecategories))->contains($CategoryId)) ? 'selected':'' }}>{{ $Name }}</option>

                                @endforeach
                                @endif

                            </select>
                        </div>
                    </div>

                </fieldset>

                <fieldset>

                    <div class="row">
                        <div class="col-md-6">

                            <label class="control-label">Logo(200x200)</label>
                            <div>
                                <input type="file" class="btn btn-default" id="LogoUrl" name="LogoUrl">
                                <p class="help-block">

                                </p>
                            </div>
                            @if(isset($Model->LogoUrl))
                            <img style="width: 100px;" src="{{ url('/storage/storelogo').'/'.$Model->LogoUrl }}">
                            @endif



                        </div>
                        <div class="col-md-6">

                            <label class="control-label">Logo(600x400)</label>
                            <div>
                                <input type="file" class="btn btn-default" id="LogoUrl600X400" name="LogoUrl600X400">
                                <p class="help-block">

                                </p>
                            </div>
                            @if(isset($Model->LogoUrl600X400))
                            <img style="width: 100px;" src="{{ url('/storage/storelogo').'/'.$Model->LogoUrl600X400 }}">
                            @endif

                        </div>
                    </div>


                </fieldset>


                <fieldset>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Other Options</label>
                            <div>
                                <label class="checkbox-inline ">
                                    <input id="IsTopStore" {{ old('IsTopStore') == 1 || $Model->IsTopStore == 1 ?  'checked' : '' }} name="IsTopStore" value="1" type="checkbox" class="checkbox style-0" />

                                    <span>Top Store</span>
                                </label>
                                <label class="checkbox-inline">
                                    <input id="Enabled" name="Enabled" {{ old('Enabled') == 1 || $Model->Enabled == 1 ?  'checked' : '' }} value="1" type="checkbox" class="checkbox style-0">

                                    <span>Enabled</span>
                                </label>
                                <label class="checkbox-inline">
                                    <input id="IsHomeStore" name="IsHomeStore" {{ old('IsHomeStore') == 1 || $Model->IsHomeStore == 1 ?  'checked' : '' }} value="1" type="checkbox" class="checkbox style-0">

                                    <span>Home Store (Show at Home)</span>
                                </label>

                                <!-- <input name="Enabled" value="1" type="hidden"></input>
                                <input name="IsTopCategory" value="0" type="hidden"></input> -->
                            </div>

                        </div>
                    </div>
                </fieldset>
                <br />
                <legend>Store Content Info</legend>
                <fieldset>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 1</label>

                            <input type="text" class="form-control" name="Header1" value="{{ old('Header1', $Model->Header1) }}" placeholder="Header 1" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Description 1</label>

                            <textarea rows="4" class="form-control" name="Description1" placeholder="Description 1">{{ old('Description1', $Model->Description1) }}</textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 2</label>

                            <input type="text" class="form-control" name="Header2" value="{{ old('Header2', $Model->Header2) }}" placeholder="Header 2" />
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Description 2</label>

                            <textarea rows="4" class="form-control" name="Description2" placeholder="Description 2">{{ old('Description2', $Model->Description2) }}</textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 3</label>

                            <input type="text" class="form-control" name="Header3" value="{{ old('Header3', $Model->Header3) }}" placeholder="Header 3" />
                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Description 3</label>

                            <textarea rows="4" class="form-control" name="Description3" placeholder="Description 3">{{ old('Description3', $Model->Description3) }}</textarea>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 4</label>

                            <input type="text" class="form-control" name="Header4" value="{{ old('Header4', $Model->Header4) }}" placeholder="Header 4" />
                        </div>
                        <div class="col-md-6">

                            <label class="control-label">Description 4</label>

                            <textarea rows="4" class="form-control" name="Description4" placeholder="Description 4">{{ old('Description4', $Model->Description4) }}</textarea>

                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Header 5</label>

                            <input type="text" class="form-control" name="Header5" value="{{ old('Header5', $Model->Header5) }}" placeholder="Header 5" />
                        </div>

                        <div class="col-md-6">
                            <label class="control-label">Description 5</label>

                            <textarea rows="4" class="form-control" name="Description5" placeholder="Description 5">{{ old('Description5', $Model->Description5) }}</textarea>

                        </div>
                    </div>
                </fieldset>

                <br />
                <legend>SEO Related Info</legend>
                <fieldset>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Keyword in Url</label>

                            <input type="text" value="coupon-code" class="form-control" id="Keyword" name="Keyword" value="{{ old('Keyword', $Model->Keyword) }}" placeholder="Search Name" data-bv-group=".col-md-6" data-bv-notempty="true" data-bv-notempty-message="Information Required" />
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="control-label">Meta Title</label>

                            <input type="text" class="form-control" name="MetaTitle" value="{{ old('MetaTitle', $Model->MetaTitle) }}" placeholder="Meta Title" />
                        </div>
                        <div class="col-md-6">
                            <label class="control-label">Meta Keyword</label>

                            <input type="text" class="form-control" name="MetaKeyword" value="{{ old('MetaKeyword', $Model->MetaKeyword) }}" placeholder="Meta Keyword" />
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <label class="control-label">Meta Description</label>

                            <textarea rows="4" class="form-control" name="MetaDescription" placeholder="Meta Description">{{ old('MetaDescription', $Model->MetaDescription) }}</textarea>
                        </div>
                    </div>
                </fieldset>
                <input name="StoreId" value="{{$Model->StoreId}}" type="hidden"></input>
                @can('Store Edit')
                <div class="form-actions">
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-primary" onsubmit="return validateForm()" type="submit">
                                <i class="fa fa-save"></i>
                                Update Store
                            </button>
                        </div>
                    </div>
                </div>
                @endcan

            </form>
        </div>
        <!-- end widget content -->

    </div>
    <!-- end widget div -->

</div>
<!-- end widget -->

</div>

@endsection
@section('pagescripts')
<script>
    $('#updateStoreForm').bootstrapValidator({
        excluded: ':disabled'
    });
</script>

@endsection