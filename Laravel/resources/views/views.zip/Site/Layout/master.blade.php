<!DOCTYPE html>
<html lang="en">

<head>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-109857527-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-109857527-1');
    </script>
    <!-- Meta -->
    <meta charset="utf-8">
    <!-- Always force latest IE rendering engine -->
    <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="commission-factory-verification" content="a5461ff1bbac46a2bd184d44701c8bfb" />
    <meta name="verify-admitad" content="68f2cce45e" />
    <meta name="google-site-verification" content="hu2PHfo24R6-U1hWkz4y0aThJz2SKAbIEBDgJt-vkBs" />


    <meta name="robots" content="index, follow">


    @yield('metadata')




    <!-- FAVICONS -->
    <link rel="shortcut icon" href="{{ URL::asset('img/favicon/favicon.ico') }}" type=" image/x-icon">
    <link rel="icon" href="{{ URL::asset('img/favicon/favicon.ico') }}" type="image/x-icon">
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="{{ URL::asset('site/assets/css/bootstrap.min.css')}}">

    <!-- Customizable CSS -->
    <!-- <link rel="stylesheet" href="{{ URL::asset('site/assets/css/main.css')}}">
    <link rel="stylesheet" href="{{ URL::asset('site/assets/css/blue.css')}}">
    <link rel="stylesheet" href="{{ URL::asset('site/assets/css/owl.carousel.css')}}">
    <link rel="stylesheet" href="{{ URL::asset('site/assets/css/owl.transitions.css')}}">
    <link rel="stylesheet" href="{{ URL::asset('site/assets/css/rateit.css')}}">
    <link rel="stylesheet" href="{{ URL::asset('site/assets/css/bootstrap-select.min.css')}}"> -->

    <link rel="stylesheet" href="{{ mix('css/site.css') }}">
    <!-- Icons/Glyphs -->
    <link rel="stylesheet" href="{{ URL::asset('site/assets/css/font-awesome.css')}}">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Barlow:200,300,300i,400,400i,500,500i,600,700,800" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

    @yield('pagestyles')
</head>

<body class="cnt-home">
    <noscript>
        <div class="noscript alert-error"> For full functionality of this site it is necessary to enable JavaScript. Here are the <a href="http://www.enable-javascript.com/" target="_blank"> instructions how to enable JavaScript in your web browser</a>. </div>
    </noscript>
    <!-- ============================================== HEADER ============================================== -->
    <header class="header-style-1">

        <!-- ============================================== TOP MENU ============================================== -->
        <div class="top-bar animate-dropdown">
            <div class="container">
                <div class="header-top-inner">
                    @yield('headerdeal')
                    <!-- /.cnt-account -->

                    <!-- /.list-unstyled -->
                    <!-- /.cnt-cart -->
                    <div class="clearfix"></div>
                </div>
                <!-- /.header-top-inner -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.header-top -->
        <!-- ============================================== TOP MENU : END ============================================== -->
        <div class="main-header">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-lg-2 col-sm-12 col-md-3 logo-holder">
                        <!-- ============================================================= LOGO ============================================================= -->
                        <div class="logo"> <a href="{{ url('') }}"> <img src="{{ URL::asset('site/assets/images/logo.png')}}" alt="logo"> </a> </div>
                        <!-- /.logo -->
                        <!-- ============================================================= LOGO : END ============================================================= -->
                    </div>
                    <!-- /.logo-holder -->

                    <div class="col-lg-5 col-md-4 col-sm-5 col-xs-12 top-search-holder">
                        <!-- /.contact-row -->
                        <!-- ============================================================= SEARCH AREA ============================================================= -->
                        <div class="search-area">
                            <!-- <form>
                                <div class="control-group">
                                    <input class="search-field" placeholder="Search here..." />
                                    <a class="search-button" href="#"></a> </div>
                            </form> -->
                            <form onsubmit="onSearch(); return false;">
                                <div class="control-group">
                                    <input type="text" name="searchStoreInput" autocomplete="off" id="searchStoreInput" class="search-field" placeholder="Enter Keyword Here ..." onKeyUp="onSearch()" required>
                                    <button type="submit" class="search-button"> </button>
                                </div>
                                <div class=" input-group col-lg-12 col-md-12 col-sm-12 col-xs-12" style="z-index:10000;position:absolute;">
                                    <div id="suggesionDiv"> </div>
                                </div>
                            </form>

                            <!-- <form onsubmit="onSearch(); return false;">
                                <div class="input-group">
                                    <input type="text" name="searchStoreInput" autocomplete="off" id="searchStoreInput" class="form-control input-lg search-input" placeholder="Enter Keyword Here ..." onKeyUp="onSearch()" required>
                                    <div class="input-group-btn">
                                        <div class="input-group">
                                            <div class="input-group-btn">
                                                <button type="submit" class="btn btn-lg btn-search btn-block"> <i class="fa fa-search font-16"></i> </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=" input-group col-lg-12 col-md-12 col-sm-12 col-xs-12" style="z-index:10000;position:absolute;">
                                    <div id="suggesionDiv"> </div>
                                </div>
                            </form> -->
                        </div>
                        <!-- /.search-area -->
                        <!-- ============================================================= SEARCH AREA : END ============================================================= -->
                    </div>
                    <!-- /.top-search-holder -->

                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 navmenu">
                        <div class="yamm navbar navbar-default" role="navigation">
                            <div class="navbar-header">
                                <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                                    <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                            </div>
                            <div class="nav-bg-class">
                                <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                                    <div class="nav-outer">
                                        <ul class="nav navbar-nav">
                                            <li class="dropdown"> <a href="{{ url('') }}" data-hover="dropdown">Home</a>
                                            </li>
                                            <li class="dropdown"> <a href="{{ url('stores') }}" data-hover="dropdown">Store</a>

                                            </li>
                                            <li class="dropdown"> <a href="{{ url('categories') }}" data-hover="dropdown">Category</a>

                                            </li>

                                            @yield('specialevents')

                                        </ul>

                                        <!-- /.navbar-nav -->
                                        <div class="clearfix"></div>
                                    </div>
                                    <!-- /.nav-outer -->
                                </div>
                                <!-- /.navbar-collapse -->

                            </div>
                            <!-- /.nav-bg-class -->
                        </div>
                        <!-- /.navbar-default -->
                        <div class="top-cart-row">
                            <!-- ============================================================= SHOPPING CART DROPDOWN ============================================================= -->

                            <div class="dropdown dropdown-cart"> <a href="#" class="dropdown-toggle lnk-cart" data-toggle="dropdown">
                                    <div class="items-cart-inner">
                                        <div class="total-price-basket"> <span class="lbl">Blog</span> </div>
                                    </div>
                                </a>

                                <!-- /.dropdown-menu-->
                            </div>
                            <!-- /.dropdown-cart -->

                            <!-- ============================================================= SHOPPING CART DROPDOWN : END============================================================= -->
                        </div>
                    </div>
                    <!-- /.container-class -->



                </div>

                <!-- /.row -->

            </div>
            <!-- /.container -->

        </div>
        <!-- /.main-header -->



    </header>

    <!-- ============================================== HEADER : END ============================================== -->

    @yield('content')


    <!-- /.homebanner-holder -->



    <!-- /.row -->


    </div>
    <!-- /#top-banner-and-menu -->
    <section class="section coupons-section" style="background-image: none;position: absolute;">
        <div id="CouponModal" class="modal fade" role="dialog">

        </div>
    </section>


    @yield('footer')

    <!-- For demo purposes – can be removed on production -->

    <!-- For demo purposes – can be removed on production : End -->

    <!-- JavaScripts placed at the end of the document so the pages load faster -->
    <!-- <script src="{{ URL::asset('site/assets/js/jquery-1.11.1.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/bootstrap.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/bootstrap-hover-dropdown.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/owl.carousel.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/echo.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/jquery.easing-1.3.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/bootstrap-slider.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/jquery.rateit.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/lightbox.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/bootstrap-select.min.js')}}"></script> -->

    <!-- <script src="{{ URL::asset('site/assets/js/wow.min.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/scripts.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/countdown.js')}}"></script>
    <script src="{{ URL::asset('site/assets/js/jquery.form.min.js')}}"></script> -->
    <script src="{{ mix('js/site.js') }}"></script>

    <script>
        function onCopounClick(obj) {
            showCouponPopup($(obj).data('url'));
            window.open($(obj).data('affiliateurl'), "_blank");
        }

        function openInNewTab(obj) {
            window.open($(obj).data('url'), "_blank");
        }

        function showCouponPopup(t, u) {

            $.ajax({
                type: "Get",
                cache: !1,
                contentType: "text/html",
                url: t,
                success: function(u) {
                    $("#CouponModal").html(u);
                    $("#CouponModal").modal({
                        backdrop: 'static',
                        keyboard: false
                    });
                    setAutoCopy();

                    $("#subscribeForm1").ajaxForm(function() {
                        $("#subscribeForm1").trigger("reset");
                        $(".newsletter-form1").html('<i class="fa fa-check-circle siteIcon" aria-hidden="true"></i> Thanks! You\'re subscribed to the Saveecoupons weekly email newsletter!')
                    });
                }
            })
        }

        function setAutoCopy() {
            var e = document.querySelector(".js-textareacopybtn");
            null != e && e.addEventListener("click", function(e) {
                var t = document.querySelector(".js-copytextarea");
                t.select();
                try {
                    document.execCommand("copy");
                } catch (c) {}
            })
        }

        $(function() {
            $("#subscribeForm").ajaxForm(function() {
                $("#subscribeForm").trigger("reset");
                $(".newsletter-form").html('<i class="fa fa-check-circle siteIcon" aria-hidden="true"></i> Thanks! You\'re subscribed to the Saveecoupons weekly email newsletter!')
            });
        });


        var dthen1 = new Date($(".countbox_1").data("enddtime"));

        var start_date = new Date();
        var dnow1 = new Date(start_date);
        if (CountStepper > 0)
            ddiff = new Date((dnow1) - (dthen1));
        else
            ddiff = new Date((dthen1) - (dnow1));
        gsecs1 = Math.floor(ddiff.valueOf() / 1000);

        var iid1 = "countbox_1";
        CountBack_slider(gsecs1, "countbox_1", 1);

        function onSearch() {
            var e = $("#searchStoreInput").val();
            if ("" != e.trim()) {
                var n = "{{ route('site.siteSearch','keyword') }}".replace("keyword", e);
                // CallAjaxService("GET", null, n, "", function(e) {
                //     alert(e);
                //     $("#suggesionDiv").html(e);
                // })

                $.ajax({
                    type: "Get",
                    cache: !1,
                    contentType: "text/html",
                    url: n,
                    success: function(u) {
                        $("#suggesionDiv").html(u);
                    }
                });

            } else {
                $("#suggesionDiv").html("");
                return
            }

        }
    </script>
    @yield('pagescripts')
</body>

</html>