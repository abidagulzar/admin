<div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">

        <div class="modal-body">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div>
                <img class="img-responsive" src="{{ url('/storage/storelogo').'/'.$Model->StoreLogoUrl }}" alt="">
                <h3 class="mb-20">{{$Model->Header}}</h3>
                <div class="coupon-content">{{$Model->Description}}
                    <span style="color: #ed6663; display:block; margin-top:10px;"><a style="color: #ed6663; text-decoration:underline" href="{{ $Model->CouponUrl }}" target="_blank">Visit our Store</a></span>
                </div>

            </div>

            <div>
                @if($Model->Code == '')
                <h6 class="color-mid">No code needed!</h6>
                <div class="copy-coupon-wrap">
                    <a class="coupon-code" href="{{ $Model->CouponUrl }}" target="_blank">Continue to Store</a>
                </div>
                @else
                <h6 class="color-mid">Click below code for copy and paste this code at <a href="{{ $Model->CouponUrl }}" target="_blank">{{$Model->StoreName}}.com</a></h6>
                <div class="copy-coupon-wrap">
                    <input type="text" value="{{$Model->Code}}" readonly style="cursor: pointer;" class="coupon-code js-textareacopybtn js-copytextarea">
                </div>
                @endif
            </div>
        </div>

        <div class="modal-footer">
            <h4>Subscribe to Mail</h4>
            <p>Get our Daily email newsletter with Special Services, Updates, Offers and more!</p>
            <div class="newsletter-form1">
                <form id="subscribeForm1" class="mc4wp-form mc4wp-form-1257" action="{{ route('site.subscribe') }}" method="post">
                    @csrf
                    <div class="mc4wp-form-fields">
                        <div id="container_form_news">
                            <div id="container_form_news2">
                                <input type="Email" id="newsletter1" name="Email" placeholder="Your email address" required>
                                <button type="submit" class="button subscribe"><span>Subscribe</span></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>


    </div>

</div>