<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Coupon;
use App\Store;
use App\Category;
use App\CouponCategory;
use Illuminate\Http\Request;
use DataTables;
use App\Helpers\AppHelper;
use Illuminate\Support\Facades\DB;
use Auth;
use DateTime;

class CouponController extends Controller
{

    function __construct()
    {
        $this->middleware('permission:Coupon View|Coupon Create|Coupon Edit|Coupon Delete', ['only' => ['index', 'createpost']]);
        $this->middleware('permission:Coupon Create', ['only' => ['create', 'createpost']]);
        $this->middleware('permission:Coupon Edit', ['only' => ['edit', 'updatepost']]);
        $this->middleware('permission:Coupon Delete', ['only' => ['delete']]);
        $this->middleware('permission:Home Banner View', ['only' => ['homebanner']]);
        $this->middleware('permission:Home Coupon/Deals View', ['only' => ['homecoupon']]);
        $this->middleware('permission:Coupon Rank', ['only' => ['couponrank']]);
    }



    public function index(Request $request)
    {

        if ($request->ajax()) {

            $data = DB::table('Coupon')->select('Coupon.CouponId', 'Coupon.IsHomeBanner', 'Coupon.Code', 'Coupon.Header', 'Coupon.ExpiryDate', 'Coupon.IsTopDeal', 'Coupon.IsBanner', 'Coupon.HomeCoupon', 'Coupon.IsHeaderDeal', 'Coupon.IsUnknownOutGoing', 'Coupon.IsHomeBanner', 'Coupon.StoreRank', 'Coupon.CreateDate', 'Coupon.UpdateDate', 'UpdatedBy.Name As UpdatedByUser', 'CreatedBy.Name As CreatedByUser')->leftJoin('users as UpdatedBy', 'Coupon.UpdatedByUserId', '=', 'UpdatedBy.id')->leftJoin('users as CreatedBy', 'Coupon.CreatedByUserId', '=', 'CreatedBy.id')->where('Coupon.StoreId', $request->get('StoreId'))->orderBy('Coupon.CreateDate', 'DESC')->get();

            return Datatables::of($data)
                ->addIndexColumn()
                ->rawColumns(['action'])
                ->make(true);
        } else {
            $stores = Store::all()->pluck('Name', 'StoreId')->toArray();
            return view('Admin.Coupon.index', [
                'stores' => $stores
            ]);
        }
    }

    public function homebanner(Request $request)
    {

        if ($request->ajax()) {


            //$data = Coupon::select('CouponId', 'Code', 'Header', 'ExpiryDate', 'IsBanner', 'HomeCoupon', 'IsHeaderDeal', 'IsUnknownOutGoing', 'IsHomeBanner', 'BannerUrl')->where('IsBanner', '1')->where('IsHomeBanner', '1')->orderBy('Coupon.CreateDate', 'DESC')->get();

            $data = DB::table('Coupon')->select('Coupon.CouponId', 'Coupon.Code', 'Coupon.Header', 'Coupon.ExpiryDate', 'Coupon.IsBanner', 'Coupon.IsTopDeal', 'Coupon.HomeCoupon', 'Coupon.IsHeaderDeal', 'Coupon.IsUnknownOutGoing', 'Coupon.IsHomeBanner', 'Coupon.BannerUrl', 'Store.Name As StoreName', 'Coupon.CreateDate', 'Coupon.UpdateDate', 'UpdatedBy.Name As UpdatedByUser', 'CreatedBy.Name As CreatedByUser')->leftJoin('Store', 'Coupon.StoreId', '=', 'Store.StoreId')->leftJoin('users as UpdatedBy', 'Coupon.UpdatedByUserId', '=', 'UpdatedBy.id')->leftJoin('users as CreatedBy', 'Coupon.CreatedByUserId', '=', 'CreatedBy.id')->where('Coupon.IsBanner', '1')->where('Coupon.IsHomeBanner', '1')->orderBy('Coupon.CreateDate', 'DESC')->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->rawColumns(['action'])
                ->make(true);
        } else {

            return view('Admin.Coupon.homebanner');
        }
    }

    public function homecoupon(Request $request)
    {

        if ($request->ajax()) {


            // $data = Coupon::select('CouponId', 'Code', 'Header', 'ExpiryDate', 'IsBanner', 'HomeCoupon', 'IsHeaderDeal', 'IsUnknownOutGoing', 'IsHomeBanner', 'LogoUrl')->where('HomeCoupon', '1')->orderBy('Coupon.CreateDate', 'DESC')->get();

            $data = DB::table('Coupon')->select('Coupon.CouponId', 'Coupon.Code', 'Coupon.Header', 'Coupon.ExpiryDate', 'Coupon.IsBanner', 'Coupon.IsTopDeal', 'Coupon.HomeCoupon', 'Coupon.IsHeaderDeal', 'Coupon.IsUnknownOutGoing', 'Coupon.IsHomeBanner', 'Coupon.LogoUrl', 'Store.Name As StoreName', 'Coupon.CreateDate', 'Coupon.UpdateDate', 'UpdatedBy.Name As UpdatedByUser', 'CreatedBy.Name As CreatedByUser')->leftJoin('Store', 'Coupon.StoreId', '=', 'Store.StoreId')->leftJoin('users as UpdatedBy', 'Coupon.UpdatedByUserId', '=', 'UpdatedBy.id')->leftJoin('users as CreatedBy', 'Coupon.CreatedByUserId', '=', 'CreatedBy.id')->where('Coupon.HomeCoupon', '1')->orderBy('Coupon.CreateDate', 'DESC')->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->rawColumns(['action'])
                ->make(true);
        } else {

            return view('Admin.Coupon.homecoupon');
        }
    }

    public function couponrank(Request $request)
    {
        if ($request->ajax()) {
            $data = Store::select('StoreId', 'Name', 'Header1', 'LogoUrl', 'SearchName')->orderBy('Coupon.CreateDate', 'DESC')->orderBy('Coupon.CreateDate', 'DESC')->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->rawColumns(['action'])
                ->make(true);
        } else {
            $stores = Store::all()->pluck('Name', 'StoreId')->toArray();
            return view('Admin.Coupon.couponrank', [
                'stores' => $stores

            ]);
        }
    }

    public function GetCouponForRank($id)
    {
        $where = array('StoreId' => $id);
        $copouns = Coupon::select('CouponId', 'Code', 'Header', 'ExpiryDate', 'CopounTypeText', 'IsUnknownOutGoing', 'StoreRank')->where($where)->orderBy('StoreRank', 'ASC')->orderBy('Coupon.CreateDate', 'DESC')->get();
        foreach ($copouns as $coupon) {
            if (isset($coupon->ExpiryDate))
                $coupon->ExpiryDate =  AppHelper::instance()->DateToString($coupon->ExpiryDate);
        }
        return view('Admin.Coupon.couponrankpartial', [
            'copouns' => $copouns
        ]);
    }
    public function updaterank(Request $request)
    {
        $couponlist = json_decode($request->list, true);
        if (isset($couponlist)) {
            $length = count($couponlist);
            for ($i = 0; $i < $length; $i++) {
                $coupon = Coupon::find($couponlist[$i]);
                $coupon->StoreRank = ($i + 1);
                $coupon->save();
            }
            return "1";
        }

        return "0";
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all()->pluck('Name', 'CategoryId')->toArray();
        $stores = Store::all()->pluck('Name', 'StoreId')->toArray();

        return view('Admin.Coupon.create', [
            'categories' => $categories,
            'stores' => $stores
        ]);
    }

    public function createpost(Request $request)
    {
        try {
            $request->validate([
                'StoreId' => 'required',
                'CouponUrl' => 'required',
                'Header' => 'required',
                'CategoryId' => 'required',
                'CopounTypeText' => 'required',
            ]);

            $data = $request->all();
            $model = new Coupon($data);
            $fileLogoUrl = $request->file('LogoUrl');
            if (isset($fileLogoUrl)) {
                $guessExtension =  $fileLogoUrl->guessExtension();
                $saveName = AppHelper::instance()->RemoveSpaces($request->get('StoreName')) . '-coupon-deal-' . time() . '.' . $guessExtension;
                $fileLogoUrl->storeAs('/couponlogo', $saveName);
                $model->LogoUrl = $saveName;
            }

            $bannerUrl = $request->file('BannerUrl');
            if (isset($bannerUrl)) {
                $guessExtension =  $bannerUrl->guessExtension();
                $saveNameBannerUrl = AppHelper::instance()->RemoveSpaces($request->get('StoreName')) . '-coupon-deal-' . time() . '.' . $guessExtension;
                $bannerUrl->storeAs('/bannerlogo', $saveNameBannerUrl);
                $model->BannerUrl = $saveNameBannerUrl;
            }

            $model->ExpiryDate = AppHelper::instance()->StringToDate($request->input('ExpiryDate'));
            $model->StartDate = AppHelper::instance()->StringToDate($request->input('StartDate'));
            $model->StoreRank = 0;
            $model->GLobalRank = 0;

            $model->CreatedByUserId = Auth::user()->id;
            $model->CreateDate = new DateTime();

            if ($model->save()) {
                $model->Category()->syncWithoutDetaching($request->input('CategoryId'));
            }

            Coupon::whereIn('StoreId', [$model->StoreId])->update([
                'StoreRank' => DB::raw('StoreRank+1'),
            ]);
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode =  $e->errorInfo[1];
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Coupon with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        } catch (\Exception $e) {

            $errorCode = $e->getCode();
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Coupon with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        }


        return redirect()->route('admin.coupon.index')
            ->with('success', 'Coupon created successfully.');
    }

    public function delete(Request $request)
    {

        $ids = explode(",", $request->get('CouponId'));

        $couponCategories = CouponCategory::whereIn('CouponId', $ids);
        $couponCategories->delete();


        $coupons = Coupon::whereIn('CouponId', $ids);

        $coupons->delete();
        return redirect()->route('admin.coupon.index')
            ->with('success', 'Coupon deleted successfully');
    }

    public function edit($id)
    {
        $where = array('CouponId' => $id);
        $coupon = Coupon::where($where)->first();

        $categories = Category::all()->pluck('Name', 'CategoryId')->toArray();
        $couponcategories = CouponCategory::where($where)->pluck('CategoryId')->toArray();
        $stores = Store::all()->pluck('Name', 'StoreId')->toArray();

        if (isset($coupon->ExpiryDate))
            $coupon->ExpiryDate = AppHelper::instance()->DateToString($coupon->ExpiryDate);
        if (isset($coupon->StartDate))
            $coupon->StartDate = AppHelper::instance()->DateToString($coupon->StartDate);

        return view('Admin.Coupon.edit', [
            'categories' => $categories,
            'Model' => $coupon,
            'couponcategories' => $couponcategories,
            'stores' => $stores
        ]);
    }



    public function updatepost(Request $request)
    {
        try {
            $request->validate([
                'StoreId' => 'required',
                'CouponUrl' => 'required',
                'Header' => 'required',
                'CategoryId' => 'required',
                'CopounTypeText' => 'required',
            ]);


            $model = Coupon::find($request->get('CouponId'));

            $model->Code =  $request->get('Code');
            $model->Header =  $request->get('Header');
            $model->Description =  $request->get('Description');
            $model->CouponUrl =  $request->get('CouponUrl');

            $model->Enabled =  $request->get('Enabled');
            $model->Expired =  $request->get('Expired');
            $model->HomeCoupon =  $request->get('HomeCoupon');
            $model->IsExclusive =  $request->get('IsExclusive');
            $model->IsHeaderDeal =  $request->get('IsHeaderDeal');
            $model->IsFlashDeal =  $request->get('IsFlashDeal');
            $model->IsBanner =  $request->get('IsBanner');
            $model->IsTopDeal =  $request->get('IsTopDeal');
            $model->IsHomeBanner =  $request->get('IsHomeBanner');
            $model->IsUnknownOutGoing =  $request->get('IsUnknownOutGoing');

            $model->CopounTypeColour =  $request->get('CopounTypeColour');
            $model->CopounTypeText =  $request->get('CopounTypeText');
            $model->OFF =  $request->get('OFF');

            $model->ExpiryDate = AppHelper::instance()->StringToDate($request->input('ExpiryDate'));
            $model->StartDate = AppHelper::instance()->StringToDate($request->input('StartDate'));

            $fileLogoUrl = $request->file('LogoUrl');
            if (isset($fileLogoUrl)) {
                $guessExtension =  $fileLogoUrl->guessExtension();
                $saveName = AppHelper::instance()->RemoveSpaces($request->get('StoreName')) . '-coupon-deal-' . time() . '.' . $guessExtension;
                $fileLogoUrl->storeAs('/couponlogo', $saveName);
                $model->LogoUrl = $saveName;
            }

            $bannerUrl = $request->file('BannerUrl');
            if (isset($bannerUrl)) {
                $guessExtension =  $bannerUrl->guessExtension();
                $saveNameBannerUrl = AppHelper::instance()->RemoveSpaces($request->get('StoreName')) . '-coupon-deal-' . time() . '.' . $guessExtension;
                $bannerUrl->storeAs('/bannerlogo', $saveNameBannerUrl);
                $model->BannerUrl = $saveNameBannerUrl;
            }

            $model->UpdatedByUserId = Auth::user()->id;
            $model->UpdateDate = new DateTime();

            if ($model->save()) {
                $model->Category()->sync($request->input('CategoryId'));
            }
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode =  $e->errorInfo[1];
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Coupon with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        } catch (\Exception $e) {

            $errorCode = $e->getCode();
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Coupon with this Name already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        }


        return redirect()->route('admin.coupon.index')
            ->with('success', 'Coupon updated successfully.');
    }
}
