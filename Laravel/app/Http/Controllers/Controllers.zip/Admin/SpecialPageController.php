<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\SpecialPage;
use App\Category;
use App\Helpers\CacheHelper;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\DB;
use Auth;
use DateTime;

class SpecialPageController extends Controller
{

    function __construct()
    {
        $this->middleware('permission:SpecialPage View|SpecialPage Create|SpecialPage Edit|SpecialPage Delete', ['only' => ['index', 'createpost']]);
        $this->middleware('permission:SpecialPage Create', ['only' => ['create', 'createpost']]);
        $this->middleware('permission:SpecialPage Edit', ['only' => ['edit', 'updatepost']]);
        $this->middleware('permission:SpecialPage Delete', ['only' => ['delete']]);
    }


    public function index(Request $request)
    {
        if ($request->ajax()) {

            $data = DB::table('SpecialPage')->select('SpecialPage.*', 'Category.Name As CategoryName', 'UpdatedBy.Name As UpdatedByUser', 'CreatedBy.Name As CreatedByUser')->leftJoin('users as UpdatedBy', 'SpecialPage.UpdatedByUserId', '=', 'UpdatedBy.id')->leftJoin('users as CreatedBy', 'SpecialPage.CreatedByUserId', '=', 'CreatedBy.id')->leftJoin('Category', 'Category.CategoryId', '=', 'SpecialPage.CategoryId')->orderBy('SpecialPage.CreateDate', 'DESC')->get();

            return Datatables::of($data)
                ->addIndexColumn()
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('Admin.SpecialPage.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $categories = Category::all()->pluck('Name', 'CategoryId')->toArray();

        return view('Admin.SpecialPage.create', [
            'categories' => $categories
        ]);
    }

    public function createpost(Request $request)
    {
        try {
            $request->validate([
                'Name' => 'required',

                'CategoryId' => 'required',
                'URL' => 'required'
            ]);

            $data = $request->all();
            $model = new SpecialPage($data);

            //  $model->SetSearchName();

            $fileLogoUrl = $request->file('LogoUrl');
            if (isset($fileLogoUrl)) {

                $guessExtension =  $fileLogoUrl->guessExtension();

                $saveName = $model->URL . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl->StoreAs('/specialpagelogo', $saveName);
                $model->LogoUrl = $saveName;
            }

            $fileLogoUrl1 = $request->file('BannerUrl');
            if (isset($fileLogoUrl1)) {

                $guessExtension =  $fileLogoUrl1->guessExtension();

                $saveName = $model->URL . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl1->StoreAs('/specialpagelogo', $saveName);
                $model->BannerUrl = $saveName;
            }

            $model->CreatedByUserId = Auth::user()->id;
            $model->CreateDate = new DateTime();

            $model->save();
            CacheHelper::instance()->ResetSpecialPage();
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode =  $e->errorInfo[1];
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['SpecialPage with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        } catch (\Exception $e) {

            $errorCode = $e->getCode();
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['SpecialPage with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        }


        return redirect()->route('admin.specialpage.index')
            ->with('success', 'Special Page created successfully.');
    }

    public function delete(Request $request)
    {

        $ids = explode(",", $request->get('SpecialPageId'));

        $SpecialPage = SpecialPage::whereIn('SpecialPageId', $ids);

        $SpecialPage->delete();
        return redirect()->route('admin.specialpage.index')
            ->with('success', 'Special Page deleted successfully');
    }

    public function edit($id)
    {
        $where = array('SpecialPageId' => $id);
        $SpecialPage = SpecialPage::where($where)->first();

        $categories = Category::all()->pluck('Name', 'CategoryId')->toArray();

        return view('Admin.SpecialPage.edit', [
            'categories' => $categories,
            'Model' => $SpecialPage
        ]);
    }



    public function updatepost(Request $request)
    {
        try {
            $request->validate([
                'Name' => 'required',
                'CategoryId' => 'required',
                'URL' => 'required',
            ]);


            $model = SpecialPage::find($request->get('SpecialPageId'));


            $model->Title =  $request->get('Title');
            $model->SubTitle =  $request->get('SubTitle');

            $model->Name =  $request->get('Name');
            $model->URL =  $request->get('URL');
            $model->CategoryId =  $request->get('CategoryId');

            $model->IsCurrentEventPage =  $request->get('IsCurrentEventPage');
            $model->IsActive =  $request->get('IsActive');


            $model->Keyword =  $request->get('Keyword');
            $model->MetaTitle =  $request->get('MetaTitle');
            $model->MetaDescription =  $request->get('MetaDescription');
            $model->MetaKeyword =  $request->get('MetaKeyword');
            $model->BigTitle =  $request->get('BigTitle');
            //  $model->SetSearchName();

            $fileLogoUrl = $request->file('LogoUrl');
            if (isset($fileLogoUrl)) {

                $md5Name = md5_file($fileLogoUrl->getRealPath());
                $guessExtension =  $fileLogoUrl->guessExtension();

                $saveName = $model->URL . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl->StoreAs('/specialpagelogo', $saveName);
                $model->LogoUrl = $saveName;
            }

            $fileLogoUrl1 = $request->file('BannerUrl');
            if (isset($fileLogoUrl1)) {

                $guessExtension =  $fileLogoUrl1->guessExtension();

                $saveName = $model->URL . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl1->StoreAs('/specialpagelogo', $saveName);
                $model->BannerUrl = $saveName;
            }

            $model->UpdatedByUserId = Auth::user()->id;
            $model->UpdateDate = new DateTime();

            $model->save();
            CacheHelper::instance()->ResetSpecialPage();
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode =  $e->errorInfo[1];
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['SpecialPage with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        } catch (\Exception $e) {

            $errorCode = $e->getCode();
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['SpecialPage with this Name already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        }


        return redirect()->route('admin.specialpage.index')
            ->with('success', 'Special Page updated successfully.');
    }
}
