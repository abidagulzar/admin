<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DataTables;
use App\Helpers\AppHelper;
use App\Helpers\CacheHelper;
use App\StoreSetting;
use Illuminate\Support\Facades\DB;
use Auth;
use DateTime;

class StoreSettingController extends Controller
{


    function __construct()
    {
        $this->middleware('permission:Store Settings View|Store Settings Create|Store Settings Edit|Store Settings Delete', ['only' => ['index', 'createpost']]);
        $this->middleware('permission:Store Settings Create', ['only' => ['create', 'createpost']]);
        $this->middleware('permission:Store Settings Edit', ['only' => ['edit', 'updatepost']]);
        $this->middleware('permission:Store Settings Delete', ['only' => ['delete']]);
    }

    public function index(Request $request)
    {
        //$storeSetting = StoreSetting::take(1)->first();


        $storeSetting = DB::table('StoreSetting')->select('StoreSetting.*', 'UpdatedBy.Name As UpdatedByUser', 'CreatedBy.Name As CreatedByUser')
            ->leftJoin('users as UpdatedBy', 'StoreSetting.UpdatedByUserId', '=', 'UpdatedBy.id')
            ->leftJoin('users as CreatedBy', 'StoreSetting.CreatedByUserId', '=', 'CreatedBy.id')
            ->first();

        // $storeSetting = DB::table('StoreSetting')->select('Coupon.CouponId', 'Coupon.IsHomeBanner', 'Coupon.Code', 'Coupon.Header', 'Coupon.ExpiryDate', 'Coupon.IsBanner', 'Coupon.HomeCoupon', 'Coupon.IsHeaderDeal', 'Coupon.IsUnknownOutGoing', 'Coupon.IsHomeBanner', 'Coupon.StoreRank', 'Coupon.CreateDate', 'Coupon.UpdateDate', 'UpdatedBy.Name As UpdatedByUser', 'CreatedBy.Name As CreatedByUser')->leftJoin('users as UpdatedBy', 'Coupon.UpdatedByUserId', '=', 'UpdatedBy.id')->leftJoin('users as CreatedBy', 'Coupon.CreatedByUserId', '=', 'CreatedBy.id')->orderBy('Coupon.CreateDate', 'DESC')->get();
        if (!isset($storeSetting))
            $storeSetting = new StoreSetting();
        return view('Admin.StoreSetting.index', [
            'Model' => $storeSetting
        ]);
    }

    public function updatepost(Request $request)
    {
        try {

            $storeSetting = StoreSetting::take(1)->first();

            if (isset($storeSetting)) {

                if (Auth::user()->isAdmin()) {
                    $storeSetting->Title =  $request->get('Title');
                    $storeSetting->Description =  $request->get('Description');
                    $storeSetting->Keywords =  $request->get('Keywords');
                    $storeSetting->Footer =  $request->get('Footer');
                }

                $storeSetting->UpdatedByUserId = Auth::user()->id;
                $storeSetting->UpdateDate = new DateTime();
            } else {
                $data = $request->all();
                $storeSetting = new StoreSetting($data);

                $storeSetting->CreatedByUserId = Auth::user()->id;
                $storeSetting->CreateDate = new DateTime();
            }

            $storeSetting->save();
            CacheHelper::instance()->ResetStoreSetting();
        } catch (\Illuminate\Database\QueryException $e) {
            return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
        } catch (\Exception $e) {
            return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
        }



        return redirect()->route('admin.storesetting.index')
            ->with('success', 'Store Settings updated successfully.');
    }
}
