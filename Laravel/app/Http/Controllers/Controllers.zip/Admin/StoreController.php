<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Store;
use App\Category;
use App\StoreCategory;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\DB;
use Auth;
use DateTime;

class StoreController extends Controller
{

    function __construct()
    {
        $this->middleware('permission:Store View|Store Create|Store Edit|Store Delete', ['only' => ['index', 'createpost']]);
        $this->middleware('permission:Store Create', ['only' => ['create', 'createpost']]);
        $this->middleware('permission:Store Edit', ['only' => ['edit', 'updatepost']]);
        $this->middleware('permission:Store Delete', ['only' => ['delete']]);
    }


    public function index(Request $request)
    {
        if ($request->ajax()) {
            // $data = Store::select('StoreId', 'Name', 'Enabled', 'Header1', 'LogoUrl', 'SearchName', 'Enabled', 'IsHomeStore')->latest()->get();

            $data = DB::table('Store')->select('Store.StoreId', 'Store.Name', 'Store.Enabled', 'Store.Header1', 'Store.LogoUrl', 'Store.SearchName', 'Store.Enabled', 'Store.IsHomeStore', 'Store.CreateDate', 'Store.UpdateDate', 'UpdatedBy.Name As UpdatedByUser', 'CreatedBy.Name As CreatedByUser')->leftJoin('users as UpdatedBy', 'Store.UpdatedByUserId', '=', 'UpdatedBy.id')->leftJoin('users as CreatedBy', 'Store.CreatedByUserId', '=', 'CreatedBy.id')->orderBy('Store.CreateDate', 'DESC')->get();

            return Datatables::of($data)
                ->addIndexColumn()
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('Admin.Store.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $categories = Category::all()->pluck('Name', 'CategoryId')->toArray();

        return view('Admin.Store.create', [
            'categories' => $categories
        ]);
    }

    public function createpost(Request $request)
    {
        try {
            $request->validate([
                'Name' => 'required',
                'Keyword' => 'required',
                'SiteUrl' => 'required',
                'StoreNetworkLink' => 'required',
                'CategoryId' => 'required'
            ]);

            $data = $request->all();
            $model = new Store($data);

            $model->SetSearchName();

            $fileLogoUrl = $request->file('LogoUrl');
            if (isset($fileLogoUrl)) {

                $guessExtension =  $fileLogoUrl->guessExtension();

                $saveName = $model->SearchName . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl->storeAs('/storelogo', $saveName);
                $model->LogoUrl = $saveName;
            }

            $fileLogoUrl600X400 = $request->file('LogoUrl600X400');
            if (isset($fileLogoUrl600X400)) {

                $guessExtension =  $fileLogoUrl600X400->guessExtension();

                $saveNameLogoUrl600X400 = $model->SearchName . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl600X400->storeAs('/storelogo', $saveNameLogoUrl600X400);
                $model->LogoUrl600X400 = $saveNameLogoUrl600X400;
            }

            $model->CreatedByUserId = Auth::user()->id;
            $model->CreateDate = new DateTime();

            if ($model->save()) {
                $model->Category()->syncWithoutDetaching($request->input('CategoryId'));
            }
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode =  $e->errorInfo[1];
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Store with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        } catch (\Exception $e) {

            $errorCode = $e->getCode();
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Store with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        }


        return redirect()->route('admin.store.index')
            ->with('success', 'Store created successfully.');
    }

    public function delete(Request $request)
    {

        $ids = explode(",", $request->get('StoreId'));

        $storeCategories = StoreCategory::whereIn('StoreId', $ids);
        $storeCategories->delete();


        $store = Store::whereIn('StoreId', $ids);

        //$store->Category()->detach($ids);
        $store->delete();
        return redirect()->route('admin.store.index')
            ->with('success', 'Store deleted successfully');
    }

    public function edit($id)
    {
        $where = array('StoreId' => $id);
        $store = Store::where($where)->first();

        $categories = Category::all()->pluck('Name', 'CategoryId')->toArray();
        $storecategories = StoreCategory::where($where)->pluck('CategoryId')->toArray();

        return view('Admin.Store.edit', [
            'categories' => $categories,
            'Model' => $store,
            'storecategories' => $storecategories
        ]);
    }

    public function storeInfo($id)
    {
        $where = array('StoreId' => $id);
        $store = Store::where($where)->first();

        $categories = Category::all()->pluck('Name', 'CategoryId')->toArray();
        $storecategories = StoreCategory::where($where)->pluck('CategoryId')->toArray();

        return view('Admin.Store.storeInfo', [
            'categories' => $categories,
            'Model' => $store,
            'storecategories' => $storecategories
        ]);
    }


    public function updatepost(Request $request)
    {
        try {
            $request->validate([
                'Name' => 'required',
                'Keyword' => 'required',
                'SiteUrl' => 'required',
                'StoreNetworkLink' => 'required',
                'CategoryId' => 'required'
            ]);


            $model = Store::find($request->get('StoreId'));

            $model->Name =  $request->get('Name');
            $model->SiteUrl =  $request->get('SiteUrl');
            $model->StoreNetworkLink =  $request->get('StoreNetworkLink');
            $model->Enabled =  $request->get('Enabled');
            $model->IsTopStore =  $request->get('IsTopStore');
            $model->IsHomeStore =  $request->get('IsHomeStore');

            $model->Header1 =  $request->get('Header1');
            $model->Description1 =  $request->get('Description1');
            $model->Header2 =  $request->get('Header2');
            $model->Description2 =  $request->get('Description2');
            $model->Header3 =  $request->get('Header3');
            $model->Description3 =  $request->get('Description3');
            $model->Header4 =  $request->get('Header4');
            $model->Description4 =  $request->get('Description4');
            $model->Header5 =  $request->get('Header5');
            $model->Description5 =  $request->get('Description5');

            $model->Keyword =  $request->get('Keyword');
            $model->MetaTitle =  $request->get('MetaTitle');
            $model->MetaDescription =  $request->get('MetaDescription');
            $model->MetaKeyword =  $request->get('MetaKeyword');

            $model->SetSearchName();

            $fileLogoUrl = $request->file('LogoUrl');
            if (isset($fileLogoUrl)) {

                $md5Name = md5_file($fileLogoUrl->getRealPath());
                $guessExtension =  $fileLogoUrl->guessExtension();

                $saveName = $model->SearchName . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl->storeAs('/storelogo', $saveName);
                $model->LogoUrl = $saveName;
            }

            $fileLogoUrl600X400 = $request->file('LogoUrl600X400');
            if (isset($fileLogoUrl600X400)) {

                $md5Name = md5_file($fileLogoUrl600X400->getRealPath());
                $guessExtension =  $fileLogoUrl600X400->guessExtension();

                $saveNameLogoUrl600X400 = $model->SearchName . '-' . time() . '.' . $guessExtension;
                $fileLogoUrl600X400->storeAs('/storelogo', $saveNameLogoUrl600X400);
                $model->LogoUrl600X400 = $saveNameLogoUrl600X400;
            }

            $model->UpdatedByUserId = Auth::user()->id;
            $model->UpdateDate = new DateTime();

            if ($model->save()) {
                $model->Category()->sync($request->input('CategoryId'));
            }
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode =  $e->errorInfo[1];
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Store with this Name or Header 1 already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        } catch (\Exception $e) {

            $errorCode = $e->getCode();
            if ($errorCode == 1062) {
                return  \Redirect::back()->withInput($request->input())->withErrors(['Store with this Name already exist']);
            } else {
                return  \Redirect::back()->withErrors(['Error:' . $e->getMessage()])->withInput($request->input())->withInput();
            }
        }


        return redirect()->route('admin.store.index')
            ->with('success', 'Store updated successfully.');
    }
}
