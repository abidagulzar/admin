<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Home;
use App\Category;
use App\HomeCategory;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\DB;
use App\Helpers\AppHelper;
use Auth;
use DateTime;

class CouponController extends Controller
{
    public function CouponPopup($storename = null, $couponid = null)
    {
        $Model = DB::table('Coupon')->select('Coupon.CouponId', 'Coupon.Code', 'Coupon.Header', 'Coupon.CouponUrl', 'Coupon.Description', 'Store.Name As StoreName', 'Store.LogoUrl As StoreLogoUrl', 'Store.SearchName As StoreSearchName')->leftJoin('Store', 'Coupon.StoreId', '=', 'Store.StoreId')->where('Coupon.CouponId', $couponid)->first();
        return view('Site.Coupon.couponpopup', compact('Model'));
    }
}
