<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Home;
use App\Category;
use App\HomeCategory;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\DB;
use App\Helpers\AppHelper;
use App\Helpers\CacheHelper;
use Auth;
use DateTime;

class StoreController extends Controller
{
    public function storeList($keyword = null)
    {
        // For Master Page Data

        $homeSetting = CacheHelper::instance()->GetHomeSetting();
        $relatedSearch = CacheHelper::instance()->GetStoreLatestSearch();
        $specialPage = CacheHelper::instance()->GetSpecialPage();

        // For Master Page Data

        if ($keyword == null)
            $keyword = 'A';

        if ($keyword == 'num')
            $stores = DB::table('Store')->select('StoreId', 'Name', 'Enabled', 'Header1', 'LogoUrl', 'SearchName', 'Enabled', 'Description1')->where('Name', 'REGEXP', '^[0-9]')->orderBy('Name', 'ASC')->get();
        else
            $stores = DB::table('Store')->select('StoreId', 'Name', 'Enabled', 'Header1', 'LogoUrl', 'SearchName', 'Enabled', 'Description1')->where('Name', 'like', $keyword . '%')->orderBy('Name', 'ASC')->get();

        return view('Site.Store.storelist', compact('homeSetting', 'relatedSearch', 'stores', 'specialPage'));
    }

    public function storeDetail($storeSearchName = null)
    {
        $storeSetting = CacheHelper::instance()->GetStoreSetting();
        $relatedSearch = CacheHelper::instance()->GetStoreLatestSearch();
        $specialPage = CacheHelper::instance()->GetSpecialPage();

        // For Master Page Data

        $store = DB::table('Store')->select('Store.*')->where('SearchName', $storeSearchName)->first();
        // $relatedStores = DB::table('CouponCategory')->select('Coupon.*', 'Store.SearchName As StoreSearchName', 'Store.Name As StoreName', 'Store.LogoUrl As StoreLogoUrl')->leftJoin('Coupon', 'Coupon.CouponId', '=', 'CouponCategory.CouponId')->leftJoin('Store', 'Store.StoreId', '=', 'Coupon.StoreId')->Where('CouponCategory.CategoryId', $store->CategoryId)->get();

        $relatedStores = DB::table('Store')->select('Store.*')
            ->whereIn('StoreId', function ($query) use ($store) {
                $query->select('StoreId')
                    ->whereIn('CategoryId', function ($query2) use ($store) {
                        $query2->select('CategoryId')
                            ->where('StoreId', $store->StoreId)
                            ->from('StoreCategory')
                            ->get();
                    })
                    ->from('StoreCategory')

                    ->get();
            })
            ->limit(15)
            ->get();


        if (isset($store)) {

            if ($store->MetaTitle == null || trim($store->MetaTitle) == '') {
                $storeSetting->Title = AppHelper::instance()->ReplaceSystemKeywords($storeSetting->Title, '@storename', $store->Name);
            } else {
                $storeSetting->Title = AppHelper::instance()->ReplaceSystemKeywords($store->MetaTitle, '@storename', $store->Name);
            }
            if ($store->MetaDescription == null || trim($store->MetaDescription) == '') {
                $storeSetting->Description = AppHelper::instance()->ReplaceSystemKeywords($storeSetting->Description, '@storename', $store->Name);
            } else {
                $storeSetting->Description = AppHelper::instance()->ReplaceSystemKeywords($store->MetaDescription, '@storename', $store->Name);
            }
            if ($store->MetaKeyword == null || trim($store->MetaKeyword) == '') {
                $storeSetting->Keywords = AppHelper::instance()->ReplaceSystemKeywords($storeSetting->Keywords, '@storename', $store->Name);
            } else {
                $storeSetting->Keywords = AppHelper::instance()->ReplaceSystemKeywords($store->MetaKeyword, '@storename', $store->Name);
            }

            $storeSetting->Footer = AppHelper::instance()->ReplaceSystemKeywords($storeSetting->Footer, '@storename', $store->Name);

            $storeCoupons = DB::table('Coupon')->select('Coupon.*')->Where('Coupon.StoreId', $store->StoreId)->orderBy('Coupon.StoreRank', 'ASC')->get();

            $headerdeal = $storeCoupons->Where('IsHeaderDeal', 1)->first();
            return view('Site.Store.storedetail', compact('storeSetting', 'relatedSearch', 'store', 'specialPage', 'storeCoupons', 'relatedStores', 'headerdeal'));
        }

        return redirect()->route('site.home');
    }
}
