<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\SpecialPage;
use App\Category;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\DB;
use Auth;
use DateTime;
use App\Helpers\AppHelper;
use App\Helpers\CacheHelper;

class SpecialPageController extends Controller
{

    public function index($specialpageURL = null)
    {

        // For Master Page Data

        $metaSetting = CacheHelper::instance()->GetHomeSetting();
        $relatedSearch = CacheHelper::instance()->GetStoreLatestSearch();
        $specialPage = CacheHelper::instance()->GetSpecialPage();

        // For Master Page Data

        $selectedSpecialPage = DB::table('SpecialPage')->select('SpecialPage.*')->where('URL', $specialpageURL)->first();

        if (isset($selectedSpecialPage)) {

            if ($selectedSpecialPage->MetaTitle == null || trim($selectedSpecialPage->MetaTitle) == '') {
                $metaSetting->Title = AppHelper::instance()->ReplaceSystemKeywords($metaSetting->Title, '@storename', $selectedSpecialPage->Name);
            } else {
                $metaSetting->Title = AppHelper::instance()->ReplaceSystemKeywords($selectedSpecialPage->MetaTitle, '@storename', $selectedSpecialPage->Name);
            }
            if ($selectedSpecialPage->MetaDescription == null || trim($selectedSpecialPage->MetaDescription) == '') {
                $metaSetting->Description = AppHelper::instance()->ReplaceSystemKeywords($metaSetting->Description, '@storename', $selectedSpecialPage->Name);
            } else {
                $metaSetting->Description = AppHelper::instance()->ReplaceSystemKeywords($selectedSpecialPage->MetaDescription, '@storename', $selectedSpecialPage->Name);
            }
            if ($selectedSpecialPage->MetaKeyword == null || trim($selectedSpecialPage->MetaKeyword) == '') {
                $metaSetting->Keywords = AppHelper::instance()->ReplaceSystemKeywords($metaSetting->Keywords, '@storename', $selectedSpecialPage->Name);
            } else {
                $metaSetting->Keywords = AppHelper::instance()->ReplaceSystemKeywords($selectedSpecialPage->MetaKeyword, '@storename', $selectedSpecialPage->Name);
            }

            $metaSetting->Footer = AppHelper::instance()->ReplaceSystemKeywords($metaSetting->Footer, '@storename', $selectedSpecialPage->Name);

            $selectedSpecialPageCoupons = DB::table('CouponCategory')->select('Coupon.*', 'Store.SearchName As StoreSearchName', 'Store.Name As StoreName', 'Store.LogoUrl As StoreLogoUrl')->leftJoin('Coupon', 'Coupon.CouponId', '=', 'CouponCategory.CouponId')->leftJoin('Store', 'Store.StoreId', '=', 'Coupon.StoreId')->Where('CouponCategory.CategoryId', $selectedSpecialPage->CategoryId)->get();

            $specialPageRelatedStores = DB::table('CouponCategory')->select('Coupon.*', 'Store.SearchName As StoreSearchName', 'Store.Name As StoreName', 'Store.LogoUrl As StoreLogoUrl')->leftJoin('Coupon', 'Coupon.CouponId', '=', 'CouponCategory.CouponId')->leftJoin('Store', 'Store.StoreId', '=', 'Coupon.StoreId')->Where('CouponCategory.CategoryId', $selectedSpecialPage->CategoryId)->get();

            return view('Site.SpecialPage.index', compact('metaSetting', 'relatedSearch', 'specialPage', 'selectedSpecialPage', 'selectedSpecialPageCoupons', 'specialPageRelatedStores'));
        }

        return redirect()->route('site.home');
    }
}
